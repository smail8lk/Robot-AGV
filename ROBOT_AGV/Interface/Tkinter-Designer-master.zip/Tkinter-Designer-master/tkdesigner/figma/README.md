Python representation of Figma nodes.

## References
- <https://www.figma.com/developers/api#files>